package com.cpan252.tekkenreborn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TekkenrebornApplicationTests {

	@Test
	void contextLoads() {
	}

}
